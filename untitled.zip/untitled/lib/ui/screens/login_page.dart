import 'package:flutter/material.dart';
import 'package:untitled/data/providers/auth_provider.dart';


class LoginPage extends StatefulWidget{
  @override
  _LoginPageState createState() {
    return _LoginPageState();
  }
}

class _LoginPageState extends State<LoginPage> {
  final backgroundColor = const Color(0xFFF5F5F5);
  final formKey = GlobalKey<FormState>();
  final emailTextController = TextEditingController();
  final passwordTextController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: backgroundColor,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 8),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon
              (Icons.phone_android,
              size: 100,
            ),

           const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 5),
                child: Text(
                  'Hello Again!',
                  style: TextStyle(
                    //fontWeight: FontWeight.bold,
                    fontSize: 35,
                  ),
                ),
              ),
            ),

           const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  'Welcome Back!',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
              ),
            ),

         

            Form(
              key: formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _createTextField(
                    controller: emailTextController,
                    hintText: "Email",
                    validator: (value) {
                if (value == null || value.isEmpty) {
                  return "Email can not be empty";
                }
              },
              ),
                  _createTextField(
                    controller: passwordTextController,
                      hintText: "Password",
                      obscureText: true,
                      validator: (value){
                  if (value==null || value.isEmpty){
                    return "Password can not be empty";
                  }
                      },
                      ),

                ],
              ),
            ),
            ElevatedButton(
              onPressed: _signIn,
              style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                      vertical: 16
                  ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                )
              ),

              child: const Text("Sign In"),
            ),


      Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Not a member? ',
              style: TextStyle(fontSize: 16),
            ),
            InkWell(
                onTap: () {
                  Navigator.of(context).pushNamed('/register');
                },
                child: const Text(
                  'Register now',
                  style: TextStyle(
                      color: Colors.blue,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                )),
          ],
        ),
      ),
          ],
        ),
      ),

    );

  }

  Future _signIn() async {
    if(!formKey.currentState!.validate()){
      return;
    }
    try{
      await authProvider.login(
          emailTextController.text,
          passwordTextController.text);
    } on Exception catch (e){
      final message = (e as dynamic).message;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(message)));

    }

  }


  Widget _createTextField({
    required String hintText,
    TextEditingController? controller,
    bool obscureText = false,
    String? Function(String? value)? validator,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
      ),
      //color: Colors.,
      child: TextFormField(
        obscureText: obscureText,
        validator: validator,
        controller: controller,
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderSide: const
            BorderSide(color: Colors.white),
            borderRadius: BorderRadius.circular(12),

          ),
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white),
            borderRadius: BorderRadius.circular(12),

          ),
          fillColor: Colors.white,
          hintText: hintText,
        ),
      ),);
  }
}
