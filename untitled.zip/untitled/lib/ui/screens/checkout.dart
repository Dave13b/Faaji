import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_paystack/flutter_paystack.dart';
import 'package:fluttertoast/fluttertoast.dart';

class CheckOutPage extends StatefulWidget {
  const CheckOutPage({Key? key}) : super(key: key);

  @override
  State<CheckOutPage> createState() => _CheckOutPageState();
}

class _CheckOutPageState extends State<CheckOutPage> {
  final payStackClient = PaystackPlugin();

  final _amountController = TextEditingController();

  final String reference =
      "unique_transaction_ref_${Random().nextInt(1000000)}";

  void _makePayment() async {
    final Charge charge = Charge()
      ..email = 'paystackcustomer@qa.team'
      ..amount = int.parse(_amountController.text) * 100
      ..reference = reference;

    final CheckoutResponse response = await payStackClient.checkout(context,
        charge: charge, method: CheckoutMethod.card);

    print('This is the response: ${response}');
    print('This is the reference: ${reference}');

    if (response.status && response.reference == reference) {
      Fluttertoast.showToast(msg: 'Successful', backgroundColor: Colors.green);
    } else {
      Fluttertoast.showToast(
          msg: "Unsuccessful",
          backgroundColor: Colors.redAccent,
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.SNACKBAR);
    }
  }

  void _startPaystack() async {
    await dotenv.load(fileName: '.env');
    String? publicKey = dotenv.env['PUBLIC_KEY'];
    payStackClient.initialize(publicKey: publicKey!);
  }

  @override
  void initState() {
    super.initState();
    _startPaystack();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Checkout',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _creatAmountTextField(
            controller: _amountController,
            hintText: 'Enter amount',
            obscureText: false,
          ),
          checkOutCard(),
        ],
      ),
    );
  }

  Widget _creatAmountTextField({
    required String hintText,
    TextEditingController? controller,
    bool obscureText = false,
  }) {
    return Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
        ),
        child: TextFormField(
          obscureText: obscureText,
          controller: controller,
          decoration: InputDecoration(
              border: OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.white),
                  borderRadius: BorderRadius.circular(12)),
              hintText: hintText),
        ));
  }

  Widget checkOutCard() {
    return InkWell(
      onTap: () {
        _makePayment();
      },
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 10),
        color: Colors.blueAccent,
        elevation: 15,
        child: Container(
          height: 100,
          child: Padding(
            padding: const EdgeInsets.all(32.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const <Widget>[
                Text(
                  "Pay with Paystack",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                Icon(
                  Icons.payment_rounded,
                  size: 30,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
