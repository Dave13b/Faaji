import 'package:flutter/cupertino.dart';

class AuthProvider extends ChangeNotifier{
  bool isLoggedIn = false;
  String? username;
  String? password;
  Future login(String username, String password) async{
    if (username != "admin") {
      throw Exception("Invalid username or password");
    }
    this.username = username;
    this.password = password;
    isLoggedIn = true;
    notifyListeners();
  }

  logout() {
    username = null;
    password = null;
    isLoggedIn = false;
    notifyListeners();

  }



}

final authProvider = AuthProvider();